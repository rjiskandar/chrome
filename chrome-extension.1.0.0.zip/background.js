chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch((e) => console.error(e));
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus && chrome.contextMenus.create({ id: "openSidePanel", title: "Open Side Panel", contexts: ["all"] });
});
chrome.contextMenus && chrome.contextMenus.onClicked && chrome.contextMenus.onClicked.addListener((e, n) => {
  e.menuItemId === "openSidePanel" && (n == null ? void 0 : n.windowId) && chrome.sidePanel.open({ windowId: n.windowId }).catch(console.error);
});
