import { a } from "../main.js";
function f(t, n) {
  for (var o = 0; o < n.length; o++) {
    const e = n[o];
    if (typeof e != "string" && !Array.isArray(e)) {
      for (const r in e) if (r !== "default" && !(r in t)) {
        const i = Object.getOwnPropertyDescriptor(e, r);
        i && Object.defineProperty(t, r, i.get ? i : { enumerable: true, get: () => e[r] });
      }
    }
  }
  return Object.freeze(Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }));
}
var s = a();
const u = f({ __proto__: null }, [s]);
export {
  u as i
};
